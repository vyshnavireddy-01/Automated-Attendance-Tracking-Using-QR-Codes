"use client"

import { useState, useEffect, useRef } from "react"
import { Html5Qrcode } from "html5-qrcode"
import { Camera, CameraOff, CheckCircle2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function QRCodeScanner({ onScan }) {
  const [scanning, setScanning] = useState(false)
  const [scanResult, setScanResult] = useState(null)
  const [attendanceType, setAttendanceType] = useState("check-in")
  const [error, setError] = useState("")
  const scannerRef = useRef(null)
  const html5QrCodeRef = useRef(null)

  useEffect(() => {
    // Clean up scanner when component unmounts
    return () => {
      if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
        html5QrCodeRef.current.stop().catch((err) => console.error(err))
      }
    }
  }, [])

  const startScanner = () => {
    setError("")
    setScanResult(null)

    const config = {
      fps: 10,
      qrbox: { width: 250, height: 250 },
      aspectRatio: 1.0,
    }

    html5QrCodeRef.current = new Html5Qrcode("qr-reader")

    html5QrCodeRef.current
      .start({ facingMode: "environment" }, config, onScanSuccess, onScanFailure)
      .then(() => {
        setScanning(true)
      })
      .catch((err) => {
        setError("Failed to start scanner: " + err.message)
        setScanning(false)
      })
  }

  const stopScanner = () => {
    if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
      html5QrCodeRef.current
        .stop()
        .then(() => {
          setScanning(false)
        })
        .catch((err) => {
          console.error("Failed to stop scanner:", err)
        })
    }
  }

  const onScanSuccess = (decodedText) => {
    // Stop scanning after successful scan
    stopScanner()

    // Set the scan result
    setScanResult(decodedText)

    // Call the onScan callback with the employee ID and attendance type
    onScan(decodedText, attendanceType)
  }

  const onScanFailure = (error) => {
    // Handle scan failure silently (no need to show every error)
    console.warn(`QR Code scanning failed: ${error}`)
  }

  const resetScanner = () => {
    setScanResult(null)
    setError("")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>QR Code Scanner</CardTitle>
        <CardDescription>Scan employee QR codes to mark attendance</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <RadioGroup value={attendanceType} onValueChange={setAttendanceType} className="flex space-x-4">
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="check-in" id="check-in" />
            <Label htmlFor="check-in">Check-in</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="check-out" id="check-out" />
            <Label htmlFor="check-out">Check-out</Label>
          </div>
        </RadioGroup>

        {error && (
          <Alert variant="destructive">
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {scanResult ? (
          <div className="flex flex-col items-center justify-center p-6 border rounded-lg bg-green-50">
            <CheckCircle2 className="h-12 w-12 text-green-500 mb-4" />
            <h3 className="text-lg font-medium">Scan Successful</h3>
            <p className="text-sm text-gray-500 mt-2">Employee ID: {scanResult}</p>
            <p className="text-sm text-gray-500">
              {attendanceType === "check-in" ? "Checked in" : "Checked out"} at {new Date().toLocaleTimeString()}
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center">
            <div
              id="qr-reader"
              ref={scannerRef}
              className="w-full max-w-sm h-64 overflow-hidden rounded-lg border"
            ></div>
            <p className="text-xs text-gray-500 mt-2">
              {scanning ? "Position the QR code within the frame to scan" : "Click 'Start Scanner' to begin scanning"}
            </p>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-center">
        {scanning ? (
          <Button variant="outline" onClick={stopScanner}>
            <CameraOff className="mr-2 h-4 w-4" />
            Stop Scanner
          </Button>
        ) : scanResult ? (
          <Button onClick={resetScanner}>Scan Another Code</Button>
        ) : (
          <Button onClick={startScanner}>
            <Camera className="mr-2 h-4 w-4" />
            Start Scanner
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}

