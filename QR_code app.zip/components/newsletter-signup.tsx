import Link from "next/link"
import { Facebook, Github, Mail, Twitter } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"

export default function NewsletterSignup() {
  return (
    <Card className="w-full max-w-md mx-auto shadow-lg">
      <CardHeader className="space-y-4 items-center text-center">
        <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center">
          <Mail className="h-6 w-6 text-white" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold tracking-tight">Subscribe to My Newsletter</h2>
          <p className="text-muted-foreground">Get the latest updates and insights delivered straight to your inbox.</p>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-3 gap-2">
          <Button variant="outline" className="w-full">
            <Facebook className="h-4 w-4 mr-2" />
            Facebook
          </Button>
          <Button variant="outline" className="w-full">
            <Twitter className="h-4 w-4 mr-2" />
            Twitter
          </Button>
          <Button variant="outline" className="w-full">
            <Github className="h-4 w-4 mr-2" />
            GitHub
          </Button>
        </div>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <Separator />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-background px-2 text-muted-foreground">Or continue with</span>
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Input type="email" placeholder="Enter your email" />
          </div>
          <Button className="w-full bg-purple-600 hover:bg-purple-700">Subscribe Now</Button>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col space-y-4 text-center text-sm text-muted-foreground">
        <div className="flex justify-center space-x-4">
          <Link href="#" className="hover:underline">
            Terms
          </Link>
          <Link href="#" className="hover:underline">
            Privacy
          </Link>
          <Link href="#" className="hover:underline">
            Help
          </Link>
        </div>
        <p>We respect your privacy. Unsubscribe at any time.</p>
      </CardFooter>
    </Card>
  )
}

