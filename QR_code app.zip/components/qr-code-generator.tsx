"use client"

import { useState } from "react"
import { QRCodeSVG } from "qrcode.react"
import { Download, Printer } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

export default function QRCodeGenerator({ employees }) {
  const [selectedEmployee, setSelectedEmployee] = useState(null)
  const { toast } = useToast()

  const handleEmployeeSelect = (employeeId) => {
    const employee = employees.find((emp) => emp.id === employeeId)
    setSelectedEmployee(employee)
  }

  const handleDownload = () => {
    const canvas = document.getElementById("qr-code-canvas")
    const pngUrl = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream")

    const downloadLink = document.createElement("a")
    downloadLink.href = pngUrl
    downloadLink.download = `${selectedEmployee.id}_qrcode.png`
    document.body.appendChild(downloadLink)
    downloadLink.click()
    document.body.removeChild(downloadLink)

    toast({
      title: "QR Code Downloaded",
      description: `QR Code for ${selectedEmployee.name} has been downloaded.`,
    })
  }

  const handlePrint = () => {
    const printWindow = window.open("", "_blank")

    printWindow.document.write(`
      <html>
        <head>
          <title>Print QR Code</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              text-align: center;
              padding: 20px;
            }
            .container {
              max-width: 400px;
              margin: 0 auto;
              border: 1px solid #ccc;
              padding: 20px;
              border-radius: 8px;
            }
            .qr-code {
              margin: 20px 0;
            }
            .employee-info {
              margin-bottom: 20px;
            }
            .employee-id {
              font-size: 14px;
              color: #666;
            }
            .employee-name {
              font-size: 18px;
              font-weight: bold;
              margin: 8px 0;
            }
            .employee-dept {
              font-size: 14px;
              color: #666;
            }
            @media print {
              .no-print {
                display: none;
              }
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="employee-info">
              <div class="employee-id">${selectedEmployee.id}</div>
              <div class="employee-name">${selectedEmployee.name}</div>
              <div class="employee-dept">${selectedEmployee.department} Department</div>
            </div>
            <div class="qr-code">
              ${document.getElementById("qr-code").innerHTML}
            </div>
            <p>Scan this QR code to mark attendance</p>
          </div>
          <div class="no-print" style="margin-top: 20px;">
            <button onclick="window.print();window.close()">Print</button>
          </div>
          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
              }, 500);
            }
          </script>
        </body>
      </html>
    `)

    printWindow.document.close()
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>QR Code Generator</CardTitle>
        <CardDescription>Generate a QR code for an employee to use for attendance</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2">Select Employee</label>
          <Select onValueChange={handleEmployeeSelect}>
            <SelectTrigger>
              <SelectValue placeholder="Select an employee" />
            </SelectTrigger>
            <SelectContent>
              {employees.length > 0 ? (
                employees.map((employee) => (
                  <SelectItem key={employee.id} value={employee.id}>
                    {employee.name} ({employee.id})
                  </SelectItem>
                ))
              ) : (
                <SelectItem value="none" disabled>
                  No employees registered
                </SelectItem>
              )}
            </SelectContent>
          </Select>
        </div>

        {selectedEmployee ? (
          <div className="flex flex-col items-center">
            <div className="bg-white p-4 rounded-lg shadow-sm" id="qr-code">
              <QRCodeSVG id="qr-code-canvas" value={selectedEmployee.id} size={200} level="H" includeMargin={true} />
            </div>
            <div className="mt-4 text-center">
              <p className="font-medium">{selectedEmployee.name}</p>
              <p className="text-sm text-gray-500">{selectedEmployee.id}</p>
              <p className="text-sm text-gray-500">{selectedEmployee.department} Department</p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-48 border-2 border-dashed border-gray-200 rounded-lg">
            <p className="text-gray-500">Select an employee to generate QR code</p>
          </div>
        )}
      </CardContent>
      {selectedEmployee && (
        <CardFooter className="flex justify-center gap-4">
          <Button variant="outline" onClick={handleDownload}>
            <Download className="mr-2 h-4 w-4" />
            Download
          </Button>
          <Button variant="outline" onClick={handlePrint}>
            <Printer className="mr-2 h-4 w-4" />
            Print
          </Button>
        </CardFooter>
      )}
    </Card>
  )
}

