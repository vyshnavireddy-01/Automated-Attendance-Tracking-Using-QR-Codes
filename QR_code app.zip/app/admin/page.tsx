"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ChevronLeft, Users, Clock, Download } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

export default function AdminPage() {
  const [employees, setEmployees] = useState([])
  const [attendance, setAttendance] = useState([])

  useEffect(() => {
    // Load data from localStorage
    const savedEmployees = JSON.parse(localStorage.getItem("employees") || "[]")
    const savedAttendance = JSON.parse(localStorage.getItem("attendance") || "[]")

    setEmployees(savedEmployees)
    setAttendance(savedAttendance)
  }, [])

  const exportToCSV = (data, filename) => {
    // Create CSV content
    const headers = Object.keys(data[0] || {}).join(",")
    const csvRows = data.map((row) => Object.values(row).join(","))
    const csvContent = [headers, ...csvRows].join("\n")

    // Create download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", filename)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const getEmployeeName = (id) => {
    const employee = employees.find((emp) => emp.id === id)
    return employee ? employee.name : "Unknown"
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleString()
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8">
        <Link href="/" className="inline-flex items-center text-sm text-gray-500 hover:text-gray-700">
          <ChevronLeft className="mr-1 h-4 w-4" />
          Back to Home
        </Link>
        <h1 className="text-3xl font-bold mt-4">Admin Dashboard</h1>
        <p className="text-gray-500 mt-1">Manage employees and view attendance records</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Employees</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{employees.length}</div>
            <p className="text-xs text-muted-foreground mt-1">Registered in the system</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Today's Check-ins</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {
                attendance.filter(
                  (a) => a.type === "check-in" && new Date(a.timestamp).toDateString() === new Date().toDateString(),
                ).length
              }
            </div>
            <p className="text-xs text-muted-foreground mt-1">Employees checked in today</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Attendance Records</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{attendance.length}</div>
            <p className="text-xs text-muted-foreground mt-1">All-time attendance entries</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="employees" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="employees" className="flex items-center">
            <Users className="mr-2 h-4 w-4" />
            Employees
          </TabsTrigger>
          <TabsTrigger value="attendance" className="flex items-center">
            <Clock className="mr-2 h-4 w-4" />
            Attendance Logs
          </TabsTrigger>
        </TabsList>
        <TabsContent value="employees">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Employee List</h2>
            <Button
              variant="outline"
              size="sm"
              onClick={() => exportToCSV(employees, "employees.csv")}
              disabled={employees.length === 0}
            >
              <Download className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
          </div>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {employees.length > 0 ? (
                  employees.map((employee) => (
                    <TableRow key={employee.id}>
                      <TableCell className="font-medium">{employee.id}</TableCell>
                      <TableCell>{employee.name}</TableCell>
                      <TableCell>{employee.department}</TableCell>
                      <TableCell>{employee.email}</TableCell>
                      <TableCell>{employee.phone}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-4 text-muted-foreground">
                      No employees registered yet
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
        <TabsContent value="attendance">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Attendance Records</h2>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                const formattedAttendance = attendance.map((a) => ({
                  employeeId: a.employeeId,
                  employeeName: getEmployeeName(a.employeeId),
                  timestamp: formatDate(a.timestamp),
                  type: a.type,
                }))
                exportToCSV(formattedAttendance, "attendance.csv")
              }}
              disabled={attendance.length === 0}
            >
              <Download className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
          </div>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Type</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {attendance.length > 0 ? (
                  [...attendance]
                    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
                    .map((record, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{record.employeeId}</TableCell>
                        <TableCell>{getEmployeeName(record.employeeId)}</TableCell>
                        <TableCell>{formatDate(record.timestamp)}</TableCell>
                        <TableCell>
                          <Badge variant={record.type === "check-in" ? "default" : "secondary"}>
                            {record.type === "check-in" ? "Check-in" : "Check-out"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-4 text-muted-foreground">
                      No attendance records yet
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

