"use client"

import { useState } from "react"
import Link from "next/link"
import { ChevronLeft, UserPlus, QrCode, Scan } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import EmployeeRegistration from "@/components/employee-registration"
import QRCodeGenerator from "@/components/qr-code-generator"
import QRCodeScanner from "@/components/qr-code-scanner"
import { useToast } from "@/hooks/use-toast"

export default function EmployeePage() {
  const [activeTab, setActiveTab] = useState("register")
  const { toast } = useToast()
  const [employees, setEmployees] = useState(() => {
    if (typeof window !== "undefined") {
      const savedEmployees = localStorage.getItem("employees")
      return savedEmployees ? JSON.parse(savedEmployees) : []
    }
    return []
  })

  const handleRegisterEmployee = (employee) => {
    const newEmployees = [...employees, employee]
    setEmployees(newEmployees)
    localStorage.setItem("employees", JSON.stringify(newEmployees))
    toast({
      title: "Registration Successful",
      description: `Employee ${employee.name} has been registered with ID: ${employee.id}`,
    })
    setActiveTab("generate")
  }

  const handleAttendanceMarked = (employeeId, type) => {
    const timestamp = new Date().toISOString()
    const attendance = JSON.parse(localStorage.getItem("attendance") || "[]")

    const newAttendance = [
      ...attendance,
      {
        employeeId,
        timestamp,
        type,
      },
    ]

    localStorage.setItem("attendance", JSON.stringify(newAttendance))

    const employee = employees.find((emp) => emp.id === employeeId)

    toast({
      title: `${type === "check-in" ? "Check-in" : "Check-out"} Successful`,
      description: `${employee?.name || "Employee"} ${type === "check-in" ? "checked in" : "checked out"} at ${new Date().toLocaleTimeString()}`,
    })
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <Link href="/" className="inline-flex items-center text-sm text-gray-500 hover:text-gray-700">
          <ChevronLeft className="mr-1 h-4 w-4" />
          Back to Home
        </Link>
        <h1 className="text-3xl font-bold mt-4">Employee Portal</h1>
        <p className="text-gray-500 mt-1">Register, generate QR code, or mark attendance</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="register" className="flex items-center">
            <UserPlus className="mr-2 h-4 w-4" />
            Register
          </TabsTrigger>
          <TabsTrigger value="generate" className="flex items-center">
            <QrCode className="mr-2 h-4 w-4" />
            Generate QR
          </TabsTrigger>
          <TabsTrigger value="scan" className="flex items-center">
            <Scan className="mr-2 h-4 w-4" />
            Scan QR
          </TabsTrigger>
        </TabsList>
        <TabsContent value="register" className="mt-6">
          <EmployeeRegistration onRegister={handleRegisterEmployee} />
        </TabsContent>
        <TabsContent value="generate" className="mt-6">
          <QRCodeGenerator employees={employees} />
        </TabsContent>
        <TabsContent value="scan" className="mt-6">
          <QRCodeScanner onScan={handleAttendanceMarked} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

